using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour
{
    public string url = "https://www.patreon.com/didkozhaty";
    public void OnMouseDown()
    {
        Debug.Log("Patreon");
        Application.OpenURL(url);
    }
}
