using System;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime;


enum FigureType
{
    pawn,
    elephant,
    horse,
    Officer,
    queen,
    king
}

enum color 
{
    white,
    black
}
class ChessVector
{
    public int x;
    public int y;
    public ChessVector(int[] xy)
    {
        this.x = xy[0];
        this.y = xy[1];
    }
    public ChessVector(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    public bool isValid()
    {
        return this.x >= 1 && this.x <= 8 &&
                this.y >= 1 && this.y <= 8;
    }
    public static ChessVector operator +(ChessVector v1, int[] v2)
    {
        return new ChessVector(v1.x + v2[0], v1.y + v2[1]);
    }
    public static bool operator ==(ChessVector v1, ChessVector v2)
    {
        object notNull1 = null ?? v1,
               notNull2 = null ?? v2;
        if(notNull1 == null || notNull2 == null)
            return false;
        return v1.x == v2.x && v1.y == v2.y;
    }
    public static bool operator !=(ChessVector v1, ChessVector v2)
    {
        return !(v1 == v2);
    }
    public static Vector3 GetVectorFromCoordinates(ChessVector vector)
    {
        return new Vector3(vector.x - 4.5f, Figure.size / 2, vector.y - 4.5f);
    }
    public static ChessVector GetCoordinatesFromVector(Vector3 vector)
    {
        return new ChessVector(System.Convert.ToInt32(vector.x + 4.5f), System.Convert.ToInt32(vector.z + 4.5f));
    }
}

abstract class Figure
{
    public static float size = 0.7f;
    public static Material[] materials = { Resources.Load<Material>("Materials/White chess"), Resources.Load<Material>("Materials/Black chess"),
                                           Resources.Load<Material>("Materials/MovePad"), Resources.Load<Material>("Materials/Invisible") };
    public static ChessVector[] castRay(ChessVector start, int[] direction)
    {
        List<ChessVector> ray = new List<ChessVector>();
        for (; (start + direction).isValid();)
        {
            start += direction;
            ray.Add(start);
            if (GetFigure((start)) != null)
                break;
        }
        return ray.ToArray();
    }
    public static ChessVector castRaySingle(ChessVector start, int[] direction)
    {
        for (; GetFigure(start) == null && start.isValid(); start += direction);
        return start;
    }
    public static bool isOnRay(ChessVector start, int[] direction, ChessVector end)
    {
        for (; start != end && start.isValid() && GetFigure(start) != null; start += direction) ;
        return start == end;
    }
   /* public static Figure operator =(Figure figure1, Figure figure2)
    {
        
    }*/
    public Figure(ChessVector vector, color color, GameObject model)
    {
        Console.WriteLine("beiubviuerbvhj");
        if (model.transform.childCount == 0)
            this.figure = model;
        else
        {
            this.figure = model.transform.GetChild(0).gameObject;
            figure.AddComponent<MeshCollider>();
        }
        this.color = color;
        this.coords = vector;
        figure.transform.position = ChessVector.GetVectorFromCoordinates(coords);
        figure.transform.localScale = new Vector3(size, size, size);
        figure.GetComponent<Renderer>().material = materials[(int)color];
        figure.AddComponent<ForFigures>();

    }
    public Figure(Figure figure)
    {
        this.figure = figure.figure;
        this.color = figure.color;
        this.coords = figure.coords;
    }
    public static void Destroy(ChessVector vector)
    {
        Figure figure = GetFigure(vector);
        if (figure == null) return;
        figure.figure.AddComponent<ForMovePads>();
        figure.figure.GetComponent<ForMovePads>().delete(figure, EventArgs.Empty);
    }
    public abstract ChessVector[] canBeat();
    public virtual bool canBeat(ChessVector vector)
    {
        bool can = false;
        foreach (ChessVector i in canBeat())
        {
            if (i == vector && isThatEnemy(i, color))
            {
                can = true;
                break;
            }
        }
        return can;
    }
    public static bool canBeBeaten(ChessVector vector, color color)
    {
        if (!vector.isValid())
            return true;
        List<Figure> beaters = new List<Figure>();

        for(int i = -1; i <= 1; i += 2)
            for(int j = -1; j <= 1; j += 2)
            {
                beaters.Add(GetFigure(castRaySingle(vector, new int[] { i, j })));
            }
        foreach (Figure i in beaters)
            if (i != null)
                if ((i is Officer || i is Queen) && isThatEnemy(i.coords, color))
                    return true;
        beaters.Clear();


        beaters.Add(GetFigure(castRaySingle(vector, new int[] { 1, 0 })));
        beaters.Add(GetFigure(castRaySingle(vector, new int[] { -1, 0 })));
        beaters.Add(GetFigure(castRaySingle(vector, new int[] { 0, 1 })));
        beaters.Add(GetFigure(castRaySingle(vector, new int[] { 0, -1 })));
        foreach (Figure i in beaters)
            if (i != null)
                if ((i is Elephant || i is Queen) && isThatEnemy(i.coords, color))
                    return true;
        beaters.Clear();

        beaters.Add(GetFigure(vector + new int[] { 2, 1 }));
        beaters.Add(GetFigure(vector + new int[] { 2, -1 }));
        beaters.Add(GetFigure(vector + new int[] { 1, 2 }));
        beaters.Add(GetFigure(vector + new int[] { -1, 2 }));
        beaters.Add(GetFigure(vector + new int[] { 1, -2 }));
        beaters.Add(GetFigure(vector + new int[] { -1, -2 }));
        beaters.Add(GetFigure(vector + new int[] { -2, -1 }));
        beaters.Add(GetFigure(vector + new int[] { -2, 1 }));
        foreach (Figure i in beaters)
            if (i != null)
                if ((i is Horse) && isThatEnemy(i.coords, color))
                    return true;
        beaters.Clear();

        for (int i = -1; i <= 1; i++)
            for (int j = -1; j <= 1; j++)
            {
                if (j == 0 && i == 0)
                    j++;
                beaters.Add(GetFigure(vector + new int[] { i, j }));
            }
        foreach (Figure i in beaters)
            if (i != null)
                if ((i is King) && isThatEnemy(i.coords, color))
                    return true;
        beaters.Clear();

        for (int i = -1; i <= 1; i += 2)
            for (int j = -1; j <= 1; j += 2)
            {
                beaters.Add(GetFigure(vector + new int[] { i, j }));
            }
        foreach (Figure i in beaters)
            if (i != null && i is Pawn)
                if(i.canBeat(vector) && isThatEnemy(i.coords, color))
                    return true;

        return false;
    }
    public static bool isThatEnemy(ChessVector vector, color color)
    {
        Figure figure = GetFigure(vector);
        if (figure == null) return true;
        if (figure.color != color) return true;
        else return false;
    }
    virtual public void move(ChessVector vector)
    {
        OnSelect(GetFigure(vector), EventArgs.Empty);
        OnSelect = (sender, e) => { };

        Destroy(vector);
        ChessVector temp = coords;
        coords = vector;
        figure.transform.position = ChessVector.GetVectorFromCoordinates(vector);
        SetFigure(this);
        chessBoard[temp.x - 1, temp.y - 1] = null;
    }
    public static void select(ChessVector vector)
    {
        OnSelect(GetFigure(vector), EventArgs.Empty);
        OnSelect = (sender, e) => { };
        selectedCanBeat.Clear();

        selected = vector;
        selectedCanBeat.AddRange(GetFigure(vector).canBeat());
        GameObject parent = GetFigure(vector).figure;
        GameObject[] moveSpheres = new GameObject[selectedCanBeat.Count];
        int counter = 0;

        foreach(ChessVector i in selectedCanBeat)
        {
            Vector3 coords = ChessVector.GetVectorFromCoordinates(i);
            bool isFigure = GetFigure(i) != null;
            moveSpheres[counter] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            moveSpheres[counter].transform.position = new Vector3(coords.x, 0.025f, coords.z);
            moveSpheres[counter].transform.localScale = new Vector3(1, 0.05f, 1);
            moveSpheres[counter].AddComponent<ForMovePads>();
            if (isFigure)
            {
                moveSpheres[counter].GetComponent<Renderer>().material = materials[((int)(GetFigure(i).color) + 1) % 2];
                GameObject killButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                killButton.transform.position = new Vector3(coords.x, size / 2, coords.z);
                killButton.transform.localScale = new Vector3(1, size + 0.1f, 1);
                killButton.GetComponent<Renderer>().material = materials[3];
                killButton.transform.parent = parent.transform;
                killButton.AddComponent<ForMovePads>();
                OnSelect += killButton.GetComponent<ForMovePads>().delete;
            }
            else
                moveSpheres[counter].GetComponent<Renderer>().material = materials[2];
            OnSelect += moveSpheres[counter].GetComponent<ForMovePads>().delete;
            moveSpheres[counter].transform.parent = parent.transform;
        }
    }
    public static EventHandler OnSelect = (sender, e) => { };
    public GameObject figure;
    public static ChessVector[] kingCoords = new ChessVector[2];
    public ChessVector coords;
    public color color;

    public static Figure GetFigure(ChessVector vector)
    {
        if (vector.isValid())
            return chessBoard[vector.x - 1, vector.y - 1];
        else 
            return null;
    }
    public static void SetFigure(Figure figure)
    {
        chessBoard[figure.coords.x - 1, figure.coords.y - 1] = figure;
    }
    public static void startGame()
    {
        makeChessboard();
        clearChessboard();
        
        SetFigure(new Elephant(new ChessVector(1, 1), color.white));
        SetFigure(new Elephant(new ChessVector(8, 1), color.white));
        SetFigure(new Horse(new ChessVector(2, 1), color.white));
        SetFigure(new Horse(new ChessVector(7, 1), color.white));
        SetFigure(new Officer(new ChessVector(3, 1), color.white));
        SetFigure(new Officer(new ChessVector(6, 1), color.white));
        SetFigure(new Queen(new ChessVector(4, 1), color.white));
        SetFigure(new King(new ChessVector(5, 1), color.white));
        for (int i = 1; i <= 8; i++)
            SetFigure(new Pawn(new ChessVector(i, 2), color.white));

        SetFigure(new Elephant(new ChessVector(1, 8), color.black));
        SetFigure(new Elephant(new ChessVector(8, 8), color.black));
        SetFigure(new Horse(new ChessVector(2, 8), color.black));
        SetFigure(new Horse(new ChessVector(7, 8), color.black));
        SetFigure(new Officer(new ChessVector(3, 8), color.black));
        SetFigure(new Officer(new ChessVector(6, 8), color.black));
        SetFigure(new Queen(new ChessVector(4, 8), color.black));
        SetFigure(new King(new ChessVector(5, 8), color.black));
        for (int i = 1; i <= 8; i++)
            SetFigure(new Pawn(new ChessVector(i, 7), color.black));
    }

    private static void clearChessboard()
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                chessBoard[i,j] = null;
            }
        }
    }
    private static void makeChessboard()
    {
        GameObject parent = GameObject.Find("Chessboard");
        Material[] materials = { Resources.Load<Material>("Materials/MeshMaterial1"),
                                 Resources.Load<Material>("Materials/MeshMaterial2")};
        for (int i = 1; i <= 8; i++)
        {
            GameObject row = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Vector3 position = ChessVector.GetVectorFromCoordinates(new ChessVector(i, 1));
            position.y = -0.5f;
            row.transform.position = position;
            row.transform.localScale = Vector3.one;
            row.GetComponent<Renderer>().material = Figure.materials[3];
            row.name = $"{i}row";
            row.transform.parent = parent.transform;
            for (int j = 1; j <= 8; j++)
            {
                position = ChessVector.GetVectorFromCoordinates(new ChessVector(i, j));
                position.y = -0.025f;
                GameObject cell = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cell.transform.parent = row.transform;
                cell.transform.position = position;
                cell.transform.localScale = new Vector3(1, 0.05f, 1);
                cell.GetComponent<Renderer>().material = materials[(i % 2 + j % 2) % 2];
                cell.name = $"{j}cell";
            }
        }/*
        for (int i = 8; i >= 1; i--)
        {
            GameObject row = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Vector3 position = ChessVector.GetVectorFromCoordinates(new ChessVector(i, 1));
            position.y = 0;
            row.transform.position = position;
            row.transform.localScale = Vector3.one;
            row.GetComponent<Renderer>().material = Figure.materials[3];
            row.name = $"{i}row";
            row.transform.parent = chessButtons.transform;
            for (int j = 8; j >= 1; j--)
            {
                position = ChessVector.GetVectorFromCoordinates(new ChessVector(i, j));
                position.y = size + 0.1f;
                GameObject cell = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cell.transform.parent = row.transform;
                cell.transform.position = position;
                cell.transform.localScale = new Vector3(1, 0.1f, 1);
                cell.GetComponent<Renderer>().material = Figure.materials[3];
                cell.AddComponent<ForButtons>();
                cell.name = $"{j}cell";
            }
        }*/
    }

    public static ChessVector selected;
    public static List<ChessVector> selectedCanBeat = new List<ChessVector>();
    public static GameObject chessButtons = GameObject.Find("ChessButtons");
    public static Figure[,] chessBoard = new Figure[8, 8];
}

public class Base : MonoBehaviour
{
    void Start()
    {
        Console.WriteLine("lorem");
        Figure.startGame();
        Debug.Log($" {Figure.GetFigure(new ChessVector(5, 1)).figure.name}");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
