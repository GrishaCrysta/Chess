using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

class Pawn : Figure
{
    public Pawn(ChessVector vector, color color) : base(vector, color, GameObject.CreatePrimitive(PrimitiveType.Cube))
    {
        figure.name = $"{color}Pawn{coords.x}{coords.y}";
    }

    override public ChessVector[] canBeat()
    {
        List<ChessVector> canBeat = new List<ChessVector>();
        if (color == color.white)
        {
            if (coords.y == 2 && GetFigure(coords + new int[] { 0, 2 }) == null
                && GetFigure(coords + new int[] { 0, 1 }) == null) canBeat.Add(coords + new int[] { 0, 2 });
            if (GetFigure(coords + new int[] { 0, 1 }) == null) canBeat.Add(coords + new int[] { 0, 1 });
            if (isThatEnemy(coords + new int[] { 1, 1 }, color)
                         && GetFigure(coords + new int[] { 1, 1 }) != null) canBeat.Add(coords + new int[] { 1, 1 });
            if (isThatEnemy(coords + new int[] { -1, 1 }, color)
                         && GetFigure(coords + new int[] { -1, 1 }) != null) canBeat.Add(coords + new int[] { -1, 1 });
        } else
        {
            if (coords.y == 7 && GetFigure(coords + new int[] { 0, -2 }) == null
                && GetFigure(coords + new int[] { 0, -1 }) == null) canBeat.Add(coords + new int[] { 0, -2 });
            if (GetFigure(coords + new int[] { 0, -1 }) == null) canBeat.Add(coords + new int[] { 0, -1 });
            if (isThatEnemy(coords + new int[] { -1, -1 }, color)
                         && GetFigure(coords + new int[] { -1, -1 }) != null) canBeat.Add(coords + new int[] { -1, -1 });
            if (isThatEnemy(coords + new int[] { 1, -1 }, color)
                         && GetFigure(coords + new int[] { 1, -1 }) != null) canBeat.Add(coords + new int[] { 1, -1 });
        }
        return canBeat.ToArray();
    }
    public override bool canBeat(ChessVector vector)
    {
        bool canBeat = false;
        if (color == color.white)
        {
            if (coords + new int[] { -1, 1 } == vector) canBeat = true;
            if (coords + new int[] { 1, 1 } == vector) canBeat = true;
        }
        else
        {
            if (coords + new int[] { -1, -1 } == vector) canBeat = true;
            if (coords + new int[] { 1, -1 } == vector) canBeat = true;
        }
        return canBeat;
    }
}
class Elephant : Figure
{
    public Elephant(ChessVector vector, color color) : base(vector, color, GameObject.CreatePrimitive(PrimitiveType.Cylinder))
    {
        figure.name = $"{color}Elephant{coords.x}{coords.y}";
        figure.transform.localScale = new Vector3(size, size / 2, size);
    }

    override public ChessVector[] canBeat()
    {
        List<ChessVector> canBeat = new List<ChessVector>(),
                          clone = new List<ChessVector>();

        canBeat.AddRange(castRay(coords, new int[] { 0, 1 }));
        canBeat.AddRange(castRay(coords, new int[] { 1, 0 }));
        canBeat.AddRange(castRay(coords, new int[] { -1, 0 }));
        canBeat.AddRange(castRay(coords, new int[] { 0, -1 }));
        canBeat.ForEach(i => clone.Add(i));

        foreach (ChessVector i in clone)
            if (!isThatEnemy(i, color) && GetFigure(i) != null)
                canBeat.Remove(i);

        return canBeat.ToArray();
    }
    public override bool canBeat(ChessVector vector)
    {
        bool can = false;
        int[,] vectors = new int[4, 2] { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } };
        for (int i = 0; i < 4; i++)
        {
            if (isOnRay(coords, new int[] { vectors[i, 0], vectors[i, 1] }, vector))
            {
                can = true;
                break;
            }
        }
        return can;
    }
}
class Horse : Figure
{
    public Horse(ChessVector vector, color color) : base(vector, color, GameObject.CreatePrimitive(PrimitiveType.Cube))
    {
        figure.name = $"{color}Horse{coords.x}{coords.y}";
        figure.transform.Rotate(0, 45, 0);
    }
    override public ChessVector[] canBeat()
    {
        List<ChessVector> canBeat = new List<ChessVector>();

        canBeat.Add(coords + new int[] { 2, 1 });
        canBeat.Add(coords + new int[] { 2, -1 });
        canBeat.Add(coords + new int[] { 1, 2 });
        canBeat.Add(coords + new int[] { -1, 2 });
        canBeat.Add(coords + new int[] { 1, -2 });
        canBeat.Add(coords + new int[] { -1, -2 });
        canBeat.Add(coords + new int[] { -2, -1 });
        canBeat.Add(coords + new int[] { -2, 1 });

        List<ChessVector> clone = new List<ChessVector>();
        canBeat.ForEach(i => clone.Add(i));

        foreach (ChessVector i in clone)
            if (!i.isValid() || (GetFigure(i) != null && !isThatEnemy(i, color)))
                canBeat.Remove(i);

        return canBeat.ToArray();
    }
}
class Officer : Figure
{
    public Officer(ChessVector vector, color color) : base(vector, color, GameObject.CreatePrimitive(PrimitiveType.Cylinder))
    {
        figure.name = $"{color}Officer{coords.x}{coords.y}";
        figure.transform.Rotate(90, 0, 0);
        figure.transform.localScale = new Vector3(0.7f, 0.35f, 0.7f);
    }

    override public ChessVector[] canBeat()
    {
        List<ChessVector> canBeat = new List<ChessVector>(),
                          clone = new List<ChessVector>();

        canBeat.AddRange(castRay(coords, new int[] { 1, 1 }));
        canBeat.AddRange(castRay(coords, new int[] { 1, -1 }));
        canBeat.AddRange(castRay(coords, new int[] { -1, 1 }));
        canBeat.AddRange(castRay(coords, new int[] { -1, -1 }));
        canBeat.ForEach(i => clone.Add(i));

        foreach (ChessVector i in clone)
            if (!isThatEnemy(i, color) && GetFigure(i) != null)
                canBeat.Remove(i);

        return canBeat.ToArray();
    }
    public override bool canBeat(ChessVector vector)
    {
        bool can = false;
        int[,] vectors = new int[4, 2] { { 1, 1 }, { -1, 1 }, { 1, -1 }, { -1, -1 } };
        for (int i = 0; i < 4; i++)
        {
            if (isOnRay(coords, new int[] { vectors[i, 0], vectors[i, 1] }, vector))
            {
                can = true;
                break;
            }
        }
        return can;
    }
}
class Queen : Figure
{
    public Queen(ChessVector vector, color color) : base(vector, color, GameObject.CreatePrimitive(PrimitiveType.Sphere))
    {
        figure.name = $"{color}Queen{coords.x}{coords.y}";
    }

    override public ChessVector[] canBeat()
    {
        List<ChessVector> canBeat = new List<ChessVector>(),
                          clone = new List<ChessVector>();

        canBeat.AddRange(castRay(coords, new int[] { 1, 1 }));
        canBeat.AddRange(castRay(coords, new int[] { 1, -1 }));
        canBeat.AddRange(castRay(coords, new int[] { -1, 1 }));
        canBeat.AddRange(castRay(coords, new int[] { -1, -1 }));
        canBeat.AddRange(castRay(coords, new int[] { 0, 1 }));
        canBeat.AddRange(castRay(coords, new int[] { 1, 0 }));
        canBeat.AddRange(castRay(coords, new int[] { -1, 0 }));
        canBeat.AddRange(castRay(coords, new int[] { 0, -1 }));
        canBeat.ForEach(i => clone.Add(i));

        foreach (ChessVector i in clone)
            if (!isThatEnemy(i, color) && GetFigure(i) != null)
                canBeat.Remove(i);

        return canBeat.ToArray();
    }
    public override bool canBeat(ChessVector vector)
    {
        bool can = false;
        int[,] vectors = new int[8, 2] { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 }, { 1, 1 }, { -1, 1 }, { 1, -1 }, { -1, -1 } };
        for (int i = 0; i < 8; i++)
        {
            if (isOnRay(coords, new int[] { vectors[i, 0], vectors[i, 1] }, vector))
            {
                can = true;
                break;
            }
        }
        return can;
    }
}
class King : Figure
{
    public static GameObject KingModel = Resources.Load<GameObject>("Models/King");
    public King(ChessVector vector, color color) : base(vector, color, GameObject.Instantiate(KingModel))
    {
        figure.name = $"{color}King{coords.x}{coords.y}";
//        Debug.Log($"Created {figure.name}");
        kingCoords[(int)color] = vector;
    }
    public override void move(ChessVector vector)
    {
        base.move(vector);
        kingCoords[(int)color] = vector;
    }

    override public ChessVector[] canBeat()
    {
        List<ChessVector> canBeat = new List<ChessVector>();

        for (int i = -1; i <= 1; i++)
            for (int j = -1; j <= 1; j++)
            {
                if (j == 0 && i == 0)
                    j++;
                canBeat.Add(coords + new int[] { i, j });
            }

        List<ChessVector> clone = new List<ChessVector>();
        canBeat.ForEach(i => clone.Add(i));

        foreach (ChessVector i in clone)
            if (canBeBeaten(i, color) || !isThatEnemy(i, color))
                canBeat.Remove(i);

        return canBeat.ToArray();
    }
}